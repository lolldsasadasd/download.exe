-- miners haven OP gui made by me
loadstring(game:HttpGet("https://raw.githubusercontent.com/ForlornWindow46/Roblox-Scripts/main/Miners%20Haven%20Orion"))()