-- working dex [synapse edition]
loadstring(game:HttpGet("https://raw.githubusercontent.com/ForlornWindow46/Roblox-Scripts/main/Dex"))()